#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <iostream>
#include <QFileDialog>
#include <QTextStream>
#include <QFile>
#include <QMessageBox>
#include <QString>
#include <stack>
#include <cstdlib>

using namespace std;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QStringList r;
    r<<"Lexema"<<"Simbolo"<<"Tipo";
    ui->tableWidget->setColumnCount(3);
    ui->tableWidget->setRowCount(100);
    ui->tableWidget->setHorizontalHeaderLabels(r);
    ui->tableWidget->verticalHeader()->setVisible(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}

class  Nodo{
public:
    QString lexema;
    QString dato;
    Nodo *siguiente=nullptr;
};
class Terminal:public Nodo{
public:

};

class NoTerminal:public Nodo{
public:

};

class Estado:public Nodo{
public:

};

class  Container{
public:
    QString type;
    QString name;
    QString value;
    Container *siguiente=nullptr;
};



void MainWindow::creaTabla()
{
    // Inicia lectura de archivo
    QFile archivo;
      QTextStream stream;
      QString nombreArchivo;
      nombreArchivo="compilador.lr";
      if(nombreArchivo.isEmpty())
        return;
      archivo.setFileName(nombreArchivo);
      archivo.open(QIODevice::ReadOnly|QIODevice::Text);
      if(!archivo.isOpen())
        {
          QMessageBox::critical(this,"Error",archivo.errorString());
          return;
        }
      stream.setDevice(&archivo);
      QString alt=(stream.readAll());
      archivo.close(); // Finaliza lectura de archivo
      QStringList plist;
      QString auxlist;
      int estado=0;


      int list=0;// Inicia eliminacion de espacios y carga a lista
      for (int r=0;r<alt.size() ;r++ ) {
          if(estado==0)
          {
           if(alt[r]=='-')
           {
               estado=1;
           }
           if(alt[r].isDigit())
           {
               estado=2;
           }
          }

          if(estado==1)
          {
              if(alt[r]=='\t' or alt[r]=='\n')
              {
                  estado=4;
              }else{
                  auxlist+=alt[r];
              }
          }
          if(estado==2)
          {
              if(alt[r]=='\t' or alt[r]=='\n')
              {
                  estado=4;
              }else{
                  auxlist+=alt[r];
              }
          }
          if(estado==4)
          {
              plist.append(auxlist);
              auxlist="";
              estado=0;
          }

      }

      for(int i=0; i<95; i++) // se carga la tabla usando lista
          for(int j=0; j<46; j++)
          {

            table[i][j]=plist[list];

            if(list<(plist.size())-1)
            {
                list++;
            }



          }
      /*QMessageBox msgBox;
      msgBox.setText(table[92][0]);
      msgBox.exec();*/
}

void MainWindow::creaTabla2()
{
    table2[0]="identificador";
    table2[1]="entero";
    table2[2]="real";
    table2[3]="cadena";
    table2[4]="tipo";
    table2[5]="opSuma";
    table2[6]="opMul";
    table2[7]="opRelac";
    table2[8]="opOr";
    table2[9]="opAnd";
    table2[10]="opNot";
    table2[11]="opIgualdad";
    table2[12]=";";
    table2[13]=",";
    table2[14]="(";
    table2[15]=")";
    table2[16]="{";
    table2[17]="}";
    table2[18]="=";
    table2[19]="if";
    table2[20]="while";
    table2[21]="return";
    table2[22]="else";
    table2[23]="$";
    table2[24]="programa";
    table2[25]="Definiciones";
    table2[26]="Definicion";
    table2[27]="DefVar";
    table2[28]="ListaVar";
    table2[29]="DefFunc";
    table2[30]="Parametros";
    table2[31]="ListaParam";
    table2[32]="BloqFunc";
    table2[33]="DefLocales";
    table2[34]="DefLocal";
    table2[35]="Sentencias";
    table2[36]="Sentencia";
    table2[37]="Otro";
    table2[38]="Bloque";
    table2[39]="ValorRegresa";
    table2[40]="Argumentos";
    table2[41]="ListaArgumentos";
    table2[42]="Termino";
    table2[43]="LlamadaFunc";
    table2[44]="SentenciaBloque";
    table2[45]="Expresion";



}

void MainWindow::creaRules()
{
    rules[0][0]="1";
    rules[0][1]="programa";
    rules[1][0]="0";
    rules[1][1]="Definiciones";
    rules[2][0]="2";
    rules[2][1]="Definiciones";
    rules[3][0]="1";
    rules[3][1]="Definicion";
    rules[4][0]="1";
    rules[4][1]="Definicion";
    rules[5][0]="4";
    rules[5][1]="DefVar";
    rules[6][0]="0";
    rules[6][1]="ListaVar";
    rules[7][0]="3";
    rules[7][1]="ListaVar";
    rules[8][0]="6";
    rules[8][1]="DefFunc";
    rules[9][0]="0";
    rules[9][1]="Parametros";
    rules[10][0]="3";
    rules[10][1]="Parametros";
    rules[11][0]="0";
    rules[11][1]="ListaParam";
    rules[12][0]="4";
    rules[12][1]="ListaParam";
    rules[13][0]="3";
    rules[13][1]="BloqFunc";
    rules[14][0]="0";
    rules[14][1]="DefLocales";
    rules[15][0]="2";
    rules[15][1]="DefLocales";
    rules[16][0]="1";
    rules[16][1]="DefLocal";
    rules[17][0]="1";
    rules[17][1]="DefLocal";
    rules[18][0]="0";
    rules[18][1]="Sentencias";
    rules[19][0]="2";
    rules[19][1]="Sentencias";
    rules[20][0]="4";
    rules[20][1]="Sentencia";
    rules[21][0]="6";
    rules[21][1]="Sentencia";
    rules[22][0]="5";
    rules[22][1]="Sentencia";
    rules[23][0]="3";
    rules[23][1]="Sentencia";
    rules[24][0]="2";
    rules[24][1]="Sentencia";
    rules[25][0]="0";
    rules[25][1]="Otro";
    rules[26][0]="2";
    rules[26][1]="Otro";
    rules[27][0]="3";
    rules[27][1]="Bloque";
    rules[28][0]="0";
    rules[28][1]="ValorRegresa";
    rules[29][0]="1";
    rules[29][1]="ValorRegresa";
    rules[30][0]="0";
    rules[30][1]="Argumentos";
    rules[31][0]="2";
    rules[31][1]="Argumentos";
    rules[32][0]="0";
    rules[32][1]="ListaArgumentos";
    rules[33][0]="3";
    rules[33][1]="ListaArgumentos";
    rules[34][0]="1";
    rules[34][1]="Termino";
    rules[35][0]="1";
    rules[35][1]="Termino";
    rules[36][0]="1";
    rules[36][1]="Termino";
    rules[37][0]="1";
    rules[37][1]="Termino";
    rules[38][0]="1";
    rules[38][1]="Termino";
    rules[39][0]="4";
    rules[39][1]="LlamadaFunc";
    rules[40][0]="1";
    rules[40][1]="SentenciaBloque";
    rules[41][0]="1";
    rules[41][1]="SentenciaBloque";
    rules[42][0]="3";
    rules[42][1]="Expresion";
    rules[43][0]="2";
    rules[43][1]="Expresion";
    rules[44][0]="2";
    rules[44][1]="Expresion";
    rules[45][0]="3";
    rules[45][1]="Expresion";
    rules[46][0]="3";
    rules[46][1]="Expresion";
    rules[47][0]="3";
    rules[47][1]="Expresion";
    rules[48][0]="3";
    rules[48][1]="Expresion";
    rules[49][0]="3";
    rules[49][1]="Expresion";
    rules[50][0]="3";
    rules[50][1]="Expresion";
    rules[51][0]="1";
    rules[51][1]="Expresion";
}


void MainWindow::on_pushButton_clicked()
{
    creaTabla();
    creaTabla2();
    creaRules();
    QString text = ui->textEdit->toPlainText();
    int estado=0;
    text+='$';
    QString lexema,simbolo,tipo;
    auxvec=0;

    for(int i=0;i<text.size();i++)
    {

        if(estado==0)
        {
            if(text[i]==' ')
            {
                i++;
            }

            if(text[i].isLetter()) //Identificar character para pasar a estado 1
            {

                estado=1;
                simbolo="identificador";
                tipo='0';


            }
            if(text[i].isDigit()) //Identificar digito para pasar a estado 2
            {
                estado=2;
                simbolo="entero";
                tipo='1';
            }
            if(text[i]=='+' or text[i]=='-')//Identificar opSuma
            {
                lexema+=text[i];
                simbolo="opSuma";
                tipo='5';
                estado=27;
            }
            if(text[i]=='*' or text[i]=='/')//Identificar opMul
            {
                lexema+=text[i];
                simbolo="opMul";
                tipo='6';
                estado=27;
            }
            if(text[i]=='<') //Identificar opRelac parte 1 estado 3
            {

                simbolo="opRelac";
                tipo='7';
                estado=3;
            }
            if(text[i]=='>') //Identificar opRelac parte 2 estado 4
            {

                simbolo="opRelac";
                tipo='7';
                estado=4;
            }
            if(text[i]=='|') //Identificar opOr estado 5
            {

                simbolo="opOr";
                tipo='8';
                estado=5;
            }
            if(text[i]=='&') //Identificar opAnd estado 6
            {

                simbolo="opAnd";
                tipo='9';
                estado=6;
            }
            if(text[i]=='=') // identificar tipo 10 o opIgualdad parte 1
            {
                lexema+=text[i];
                simbolo='=';
                tipo="18";
                i++;
                if(text[i]=='=')
                {
                    lexema+=text[i];
                    simbolo="opIgualdad";
                    tipo="11";
                    estado=27;
                }else{
                    i--;
                    estado=27;
                }

            }
            if(text[i]=='!')//Identificar opNot o opIgualdad parte 2
            {
                lexema+=text[i];
                simbolo="opNot";
                tipo="10";
                i++;
                if(text[i]=='=')
                {
                    lexema+=text[i];
                    simbolo="opIgualdad";
                    tipo="11";
                    estado=27;
                }else{
                    i--;
                    estado=27;
                }

            }
            if(text[i]==';')
            {
                lexema+=text[i];
                simbolo=';';
                tipo="12";
                estado=27;
            }
            if(text[i]==',')
            {
                lexema+=text[i];
                simbolo=',';
                tipo="13";
                estado=27;
            }
            if(text[i]=='(')
            {
                lexema+=text[i];
                simbolo='(';
                tipo="14";
                estado=27;
            }
            if(text[i]==')')
            {
                lexema+=text[i];
                simbolo=')';
                tipo="15";
                estado=27;
            }
            if(text[i]=='{')
            {
                lexema+=text[i];
                simbolo='{';
                tipo="16";
                estado=27;
            }
            if(text[i]=='}')
            {
                lexema+=text[i];
                simbolo='}';
                tipo="17";
                estado=27;
            }



            if(text[i]=='$') //Identificar Final de datos
            {

                lexema+=text[i];
                simbolo='$';
                tipo="23";
                estado=27;
            }

        }

        if(estado==1) // estado de cadenas
        {
            if(text[i].isLetter() or text[i].isDigit() or text[i]=='_')
            {
                lexema+=text[i];

            }else{
                if(lexema=="int" or lexema=="float" or lexema=="void")
                {
                    simbolo="tipo";
                    tipo='4';
                }
                if(lexema=="if")
                {
                    simbolo="if";
                    tipo="19";
                }
                if(lexema=="while")
                {
                    simbolo="while";
                    tipo="20";
                }
                if(lexema=="return")
                {
                    simbolo="return";
                    tipo="21";
                }
                if(lexema=="else")
                {
                    simbolo="else";
                    tipo="22";

                }
                i--;
                estado=27;



            }

        }
        if(estado==2) // estado de entero y real
        {
            if(text[i].isDigit())
            {
                lexema+=text[i];
            }else{
                if(text[i]=='.')
                {
                    lexema+=text[i];
                    simbolo="real";
                    tipo='2';

                }else{
                    i--;
                    estado=27;
                }


            }

        }
        if(estado==3) //estado de oprealc parte 1
        {
            if(text[i]=='<')
            {
                lexema+=text[i];


            }else{
                if(text[i]=='=')
                {
                    lexema+=text[i];
                    estado=27;

                }else{
                    i--;
                    estado=27;
                }
            }
        }
        if(estado==4)  //estado de oprealc parte 2
        {
            if(text[i]=='>')
            {
                lexema+=text[i];


            }else{
                if(text[i]=='=')
                {
                    lexema+=text[i];
                    estado=27;

                }else{
                    i--;
                    estado=27;
                }
            }
        }
        if(estado==5) //estado de opOr
        {
            if(text[i]=='|')
            {
                lexema+=text[i];
            }else{
                i--;
                estado=27;
            }
        }
        if(estado==6) //estado de opAnd
        {
            if(text[i]=='&')
            {
                lexema+=text[i];
            }else{
                i--;
                estado=27;
            }
        }

        if(estado==27)
        {
            vec[auxvec][0]=lexema;
            vec[auxvec][1]=simbolo;
            vec[auxvec][2]=tipo;

            ui->tableWidget->setItem(auxvec,0,new QTableWidgetItem(lexema));
            ui->tableWidget->setItem(auxvec,1,new QTableWidgetItem(simbolo));
            ui->tableWidget->setItem(auxvec,2,new QTableWidgetItem(tipo));
            auxvec+=1;
            lexema="";
            simbolo="error";
            tipo="";

            estado=0;


        }



    }


    //Comienza analisis sintactico
    cout<<vec[0][1].toStdString()<<endl;
    cout<<vec[1][1].toStdString()<<endl;
    stack<Nodo> mistack;
    QString auxz="0";
    Nodo aux1;
    Estado estado1;
    estado1.lexema=auxz;
    mistack.push(estado1);
    int fila,columna;
    QString accion,thing, raux, thing3,accion2;
    int thing2;
    Nodo  auxq;
    Nodo aux2q;
    Nodo  aux3q;
    Nodo  aux4q;
    Nodo  aux5q;
    Nodo  aux6q;
    Nodo  auxa;
    Nodo aux2a;
    Nodo  aux3a;
    Nodo  aux4a;
    Nodo  aux5a;
    Nodo  aux6a;
    Nodo  auxw;
    Nodo  aux2w;
    Nodo  aux3w;
    Nodo  aux4w;
    Nodo  auxws;
    Nodo  aux2ws;
    Nodo  aux3ws;
    Nodo  aux4ws;
    Nodo  auxwd;
    Nodo  aux2wd;
    Nodo  aux3wd;
    Nodo  aux4wd;
    Nodo  auxwf;
    Nodo  aux2wf;
    Nodo  aux3wf;
    Nodo  aux4wf;
    Nodo  auxe;
    Nodo  aux2e;
    Nodo  aux3e;
    Nodo  auxeg;
    Nodo  aux2eg;
    Nodo  aux3eg;
    Nodo  auxeh;
    Nodo  aux2eh;
    Nodo  aux3eh;
    Nodo  auxej;
    Nodo  aux2ej;
    Nodo  aux3ej;
    Nodo  auxek;
    Nodo  aux2ek;
    Nodo  aux3ek;
    Nodo  auxel;
    Nodo  aux2el;
    Nodo  aux3el;
    Nodo  auxez;
    Nodo  aux2ez;
    Nodo  aux3ez;
    Nodo  auxex;
    Nodo  aux2ex;
    Nodo  aux3ex;
    Nodo  auxec;
    Nodo  aux2ec;
    Nodo  aux3ec;
    Nodo  auxev;
    Nodo  aux2ev;
    Nodo  aux3ev;
    Nodo  auxeb;
    Nodo  aux2eb;
    Nodo  aux3eb;
    Nodo  auxen;
    Nodo  aux2en;
    Nodo  aux3en;
    Nodo  auxem;
    Nodo  aux2em;
    Nodo  aux3em;
    Nodo auxr;
    Nodo auxrq;
    Nodo auxrw;
    Nodo auxre;
    Nodo auxrr;
    Nodo auxrt;
    Nodo auxry;
    Nodo auxru;
    Nodo auxri;
    Nodo auxro;
    Nodo auxrp;
    Nodo auxra;
    Nodo auxrs;
    Nodo auxrd;
    Nodo  auxt ;
    Nodo  aux2t ;
    Nodo  auxtq ;
    Nodo  aux2tq ;
    Nodo  auxtw ;
    Nodo  aux2tw ;
    Nodo  auxte ;
    Nodo  aux2te ;
    Nodo  auxtr ;
    Nodo  aux2tr ;
    Nodo  auxtt ;
    Nodo  aux2tt ;
    Nodo  auxty ;
    Nodo  aux2ty ;
    Nodo  auxtu ;
    Nodo  aux2tu ;
    Nodo  auxy;
    Nodo  aux2y;
    Nodo  aux3y;
    Nodo  aux4y;
    Nodo  aux5y;

    Nodo  extra;

    Nodo change;
    Nodo change2;
    Nodo change3;
    Nodo change4;
    Nodo change5;

    Nodo m6;


    Nodo stunt;
    Nodo stunt2;
    Nodo stunt3;
    Nodo stunt4;

    Nodo stunt15;
    Nodo stunt16;
    Nodo stunt17;
    Nodo stunt18;
    int contstu=0;

    Nodo second;
    Nodo second2;
    Nodo second4;
    int sec=0;
    int sec2=0;

    Nodo kali;
    Nodo Kali2;
    Nodo Kali3;
    int ka=0;


    Nodo ubuntu;
    Nodo ubuntu2;
    Nodo ubuntu3;
    Nodo ubuntu4;
    Nodo ubuntu5;
    Nodo ubuntu6;
    Nodo ubuntu7;
    Nodo ubuntu8;
    Nodo ubuntu9;
    Nodo ubuntu10;
    int ubu=0;

    Nodo tyler;
    Nodo tyler2;
    int ty=0;

    Nodo Smith;
    int sm=0;

    Nodo frank;
    Nodo frank2;
    Nodo frank3;
    Nodo frank4;
    Nodo frank5;
    Nodo frank6;
    Nodo frank7;
    Nodo frank8;
    Nodo frank9;
    Nodo frank10;
    Nodo frank11;
    Nodo frank12;
    Nodo frank13;
    Nodo frank14;
    Nodo frank15;
    Nodo frank16;
    Nodo frank17;
    Nodo frank18;
    Nodo frank19;
    Nodo frank20;
    Nodo frank21;
    Nodo frank22;
    int fra=0;

    Nodo *trial;
    Nodo *trial2;
    Nodo *trial3;
    Nodo *trial4;
    Nodo *trial5;
    Nodo *trial6;

    Nodo t1;
    Nodo t2;
    Nodo t3;
    Nodo t4;
    Nodo t5;
    Nodo t6;
    Nodo t7;
    Nodo t8;
    Nodo t9;
    Nodo t10;
    Nodo t11;
    Nodo t12;
    Nodo t13;
    Nodo t14;
    Nodo t15;
    Nodo t16;
    Nodo t17;
    Nodo t18;
    Nodo t19;
    Nodo t20;
    Nodo t21;
    Nodo t22;
    Nodo t23;
    Nodo t24;
    Nodo t25;
    Nodo t26;
    Nodo t27;
    Nodo t28;
    Nodo t29;
    Nodo t30;
    Nodo t31;
    Nodo t32;
    Nodo t33;
    Nodo t34;
    Nodo t35;
    Nodo t36;
    Nodo t37;
    Nodo t38;
    Nodo t39;
    Nodo t40;
    Nodo t41;
    Nodo t42;
    Nodo t43;
    Nodo t44;
    Nodo t45;
    Nodo t46;
    Nodo t47;
    Nodo t48;
    Nodo t49;
    Nodo t50;
    Nodo t51;
    Nodo t52;
    Nodo t53;
    Nodo t54;
    Nodo t55;
    Nodo t56;
    Nodo t57;
    Nodo t58;
    Nodo t59;
    Nodo t60;
    Nodo t61;
    Nodo t62;
    Nodo t63;
    Nodo t64;
    Nodo t65;
    Nodo t66;
    Nodo t67;
    Nodo t68;
    Nodo t69;
    Nodo t70;
    Nodo t71;
    Nodo t72;
    Nodo t73;

    Nodo e1;
    Nodo e2;
    Nodo e3;
    Nodo e4;
    Nodo e5;
    Nodo e6;
    Nodo e7;
    Nodo e8;
    Nodo e9;
    Nodo e10;
    Nodo e11;
    Nodo e12;
    Nodo e13;
    Nodo e14;
    Nodo e15;
    Nodo e16;
    Nodo e17;
    Nodo e18;
    Nodo e19;
    Nodo e20;
    Nodo e21;
    Nodo e22;
    Nodo e23;
    Nodo e24;
    Nodo e25;
    Nodo e26;
    Nodo e27;
    Nodo e28;
    Nodo e29;
    Nodo e30;
    Nodo e31;
    Nodo e32;
    Nodo e33;
    Nodo e34;
    Nodo e35;
    Nodo e36;
    Nodo e37;
    Nodo e38;
    Nodo e39;
    Nodo e40;
    Nodo e41;
    Nodo e42;
    Nodo e43;
    Nodo e44;
    Nodo e45;
    Nodo e46;
    Nodo e47;
    Nodo e48;
    Nodo e49;
    Nodo e50;
    Nodo e51;
    Nodo e52;
    Nodo e53;
    Nodo e54;
    Nodo e55;
    Nodo e56;
    Nodo e57;
    Nodo e58;
    Nodo e59;
    Nodo e60;
    Nodo e61;
    Nodo e62;
    Nodo e63;
    Nodo e64;
    Nodo e65;
    Nodo e66;
    Nodo e67;
    Nodo e68;
    Nodo e69;
    Nodo e70;
    Nodo e71;
    Nodo e72;
    Nodo e73;

    int safety=0;

    int h1;





    int contx=0;

    while(contx<auxvec)
    {
        aux1=mistack.top();
        cout<<aux1.lexema.toInt()<<endl;


        if(aux1.lexema[0].isDigit())
        {
            int n=aux1.lexema.toInt();
            fila=n;
        }
        if(aux1.lexema[0].isLetter())
        {
            QString aux;
            for(int i=0;i<46;i++)
            {
                aux=table2[i];
                if(aux==aux1.lexema)
                {
                   fila=i;
                }

            }
        }
        for (int i=0;i<46;i++ )
        {
            QString aux;

            aux=table2[i];
            if(aux==vec[contx][1])
            {
               columna=i;
            }




         }
        cout<<"Fila "<<fila<< "Columna"<< columna<<endl;
        accion=table[fila][columna];
        cout<<"Accion: "<<accion.toStdString()<<endl;


        if(accion[0].isDigit() && accion[0]!='0')
        {
            Estado estado2;
            Terminal terminal1;
            terminal1.lexema=vec[contx][1];
            terminal1.dato=vec[contx][0];
            estado2.lexema=accion;
            mistack.push(terminal1);
            mistack.push(estado2);
            cout<<"Agregando "<<vec[contx][1].toStdString()<<" y "<<accion.toStdString()<<endl;
            contx++;


        }
        if(accion[0]=='-')
        {
            if(accion=="-1")
            {
                mistack.pop();
                Nodo *iq;
                iq=&mistack.top();
                while(iq->siguiente!=nullptr)
                {
                    cout<<iq->lexema.toStdString()<<"->"<<endl;
                    iq=iq->siguiente;

                }
                cout<<iq->lexema.toStdString()<<endl;

                QMessageBox msgBox;
                msgBox.setText("Sintacticamente correcto");
                msgBox.exec();


                break;
            }
            else{
                if(accion.size()==2)
                {
                    thing+=accion[1];
                    thing2=thing.toInt();
                    thing2=thing2-1;
                    thing="";
                }
                if(accion.size()==3)
                {
                    thing+=accion[1];
                    thing+=accion[2];
                    thing2=thing.toInt();
                    thing2=thing2-1;
                    thing="";
                }
                raux=rules[thing2-1][1];
                thing3 = QString::number(thing2);

                if(thing3=='9')
                {
                    cout<<"regla"<<thing3.toStdString()<<"  12 pops"<<endl;



                    t1.lexema=raux;
                    mistack.pop();
                    auxq=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux2q=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux3q=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux4q=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux5q=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux6q=mistack.top();
                    mistack.pop();
                    aux2q.siguiente=&auxq;
                    aux3q.siguiente=&aux2q;
                    aux4q.siguiente=&aux3q;
                    aux5q.siguiente=&aux4q;
                    aux6q.siguiente=&aux5q;
                    t1.siguiente=&aux6q;
                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e1.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t1);
                    cout<<"entra "<<t1.lexema.toStdString();
                    mistack.push(e1);
                    cout<<"Transicion "<<e1.lexema.toStdString()<<endl;
                }
                if( thing3=="22")
                {
                    cout<<"regla"<<thing3.toStdString()<<"  12 pops"<<endl;


                    t2.lexema=raux;
                    mistack.pop();
                    auxa=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux2a=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux3a=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux4a=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux5a=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux6a=mistack.top();
                    mistack.pop();
                    aux2a.siguiente=&auxa;
                    aux3a.siguiente=&aux2a;
                    aux4a.siguiente=&aux3a;
                    aux5a.siguiente=&aux4a;
                    aux6a.siguiente=&aux5a;
                    t2.siguiente=&aux6q;
                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e2.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t2);
                    cout<<"entra "<<t2.lexema.toStdString();
                    mistack.push(e2);
                    cout<<"Transicion "<<e2.lexema.toStdString()<<endl;
                }
                if(thing3=="13"  )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  8 pops"<<endl;


                    t3.lexema=raux;
                    mistack.pop();
                    auxw=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux2w=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux3w=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux4w=mistack.top();
                    mistack.pop();
                    aux2w.siguiente=&auxw;
                    aux3w.siguiente=&aux2w;
                    aux4w.siguiente=&aux3w;
                    t3.siguiente=&aux4w;
                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e3.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t3);
                    cout<<"entra "<<t3.lexema.toStdString();
                    mistack.push(e3);
                    cout<<"Transicion "<<e3.lexema.toStdString()<<endl;
                }
                if(thing3=="21"  )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  8 pops"<<endl;


                    if(ubu==0)
                    {

                        t4.lexema=raux;
                        mistack.pop();
                        auxws=mistack.top(); //this is ;
                        mistack.pop();
                        mistack.pop();
                        aux2ws=mistack.top(); // this is Expresion
                        change4=*aux2ws.siguiente; // this is termino
                        mistack.pop();
                        mistack.pop();
                        aux3ws=mistack.top(); //this is =
                        mistack.pop();
                        mistack.pop();
                        aux4ws=mistack.top(); // this is identificador
                        mistack.pop();
                        auxws.siguiente=&change4;
                        aux2ws.siguiente=&auxws;
                        aux3ws.siguiente=&aux2ws;
                        aux4ws.siguiente=&aux3ws;
                        t4.siguiente=&aux4ws;
                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e4.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t4);
                        cout<<"entra "<<t4.lexema.toStdString();
                        mistack.push(e4);
                        cout<<"Transicion "<<e4.lexema.toStdString()<<endl;
                    }
                    if(ubu==1)
                    {

                        t5.lexema=raux;
                        mistack.pop();
                        ubuntu=mistack.top(); //this is ;
                        mistack.pop();
                        mistack.pop();
                        ubuntu2=mistack.top(); // this is Expresion
                        ubuntu5=*ubuntu2.siguiente; // this is termino
                        mistack.pop();
                        mistack.pop();
                        ubuntu3=mistack.top(); //this is =
                        mistack.pop();
                        mistack.pop();
                        ubuntu4=mistack.top(); // this is identificador
                        mistack.pop();
                        ubuntu.siguiente=&ubuntu5;
                        ubuntu2.siguiente=&ubuntu;
                        ubuntu3.siguiente=&ubuntu2;
                        ubuntu4.siguiente=&ubuntu3;
                        t5.siguiente=&ubuntu4;
                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e5.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t5);
                        cout<<"entra "<<t5.lexema.toStdString();
                        mistack.push(e5);
                        cout<<"Transicion "<<e5.lexema.toStdString()<<endl;
                    }
                    if(ubu==2)
                    {

                        t6.lexema=raux;
                        mistack.pop();
                        ubuntu6=mistack.top(); //this is ;
                        mistack.pop();
                        mistack.pop();
                        ubuntu7=mistack.top(); // this is Expresion
                        ubuntu10=*ubuntu7.siguiente; // this is termino
                        mistack.pop();
                        mistack.pop();
                        ubuntu8=mistack.top(); //this is =
                        mistack.pop();
                        mistack.pop();
                        ubuntu9=mistack.top(); // this is identificador
                        mistack.pop();
                        ubuntu6.siguiente=&ubuntu10;
                        ubuntu7.siguiente=&ubuntu6;
                        ubuntu8.siguiente=&ubuntu7;
                        ubuntu9.siguiente=&ubuntu8;
                        t6.siguiente=&ubuntu9;
                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e6.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t6);
                        cout<<"entra "<<t6.lexema.toStdString();
                        mistack.push(e6);
                        cout<<"Transicion "<<e6.lexema.toStdString()<<endl;
                    }

                    ubu++;


                }
                if( thing3=="40" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  8 pops"<<endl;


                    t7.lexema=raux;
                    mistack.pop();
                    auxwd=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux2wd=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux3wd=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux4wd=mistack.top();
                    mistack.pop();
                    aux2wd.siguiente=&auxwd;
                    aux3wd.siguiente=&aux2wd;
                    aux4wd.siguiente=&aux3wd;
                    t7.siguiente=&aux4wd;
                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e7.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t7);
                    cout<<"entra "<<t7.lexema.toStdString();
                    mistack.push(e7);
                    cout<<"Transicion "<<e7.lexema.toStdString()<<endl;
                }
                if(  thing3=='6' )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  8 pops"<<endl;

                    if(contstu==0)
                    {
                        t8.lexema=raux;
                        mistack.pop();
                        auxwf=mistack.top();
                        mistack.pop();
                        mistack.pop();
                        aux2wf=mistack.top();
                        mistack.pop();
                        mistack.pop();
                        aux3wf=mistack.top();
                        mistack.pop();
                        mistack.pop();
                        aux4wf=mistack.top();
                        mistack.pop();
                        aux2wf.siguiente=&auxwf;
                        aux3wf.siguiente=&aux2wf;
                        aux4wf.siguiente=&aux3wf;
                        t8.siguiente=&aux4wf;
                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e8.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t8);
                        cout<<"entra "<<t8.lexema.toStdString();
                        mistack.push(e8);
                        cout<<"Transicion "<<e8.lexema.toStdString()<<endl;
                    }
                    if(contstu==1)
                    {
                        t69.lexema=raux;
                        mistack.pop();
                        stunt15=mistack.top();
                        mistack.pop();
                        mistack.pop();
                        stunt16=mistack.top();
                        mistack.pop();
                        mistack.pop();
                        stunt17=mistack.top();
                        mistack.pop();
                        mistack.pop();
                        stunt18=mistack.top();
                        mistack.pop();
                        stunt16.siguiente=&stunt15;
                        stunt17.siguiente=&stunt16;
                        stunt18.siguiente=&stunt17;
                        t69.siguiente=&stunt18;
                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e69.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t69);
                        cout<<"entra "<<t69.lexema.toStdString();
                        mistack.push(e69);
                        cout<<"Transicion "<<e69.lexema.toStdString()<<endl;
                    }
                    if(contstu==2)
                    {
                        t9.lexema=raux;
                        mistack.pop();
                        stunt=mistack.top();
                        mistack.pop();
                        mistack.pop();
                        stunt2=mistack.top();
                        mistack.pop();
                        mistack.pop();
                        stunt3=mistack.top();
                        mistack.pop();
                        mistack.pop();
                        stunt4=mistack.top();
                        mistack.pop();
                        stunt2.siguiente=&stunt;
                        stunt3.siguiente=&stunt2;
                        stunt4.siguiente=&stunt3;
                        t9.siguiente=&stunt4;
                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e9.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t9);
                        cout<<"entra "<<t9.lexema.toStdString();
                        mistack.push(e9);
                        cout<<"Transicion "<<e9.lexema.toStdString()<<endl;
                    }
                    contstu++;

                }
                if(thing3=="14" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  6 pops"<<endl;


                    t10.lexema=raux;
                    mistack.pop();
                    auxe=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux2e=mistack.top();
                    change2=*aux2e.siguiente;
                    mistack.pop();
                    mistack.pop();
                    aux3e=mistack.top();
                    mistack.pop();
                    auxe.siguiente=&change2;
                    aux2e.siguiente=&auxe;
                    aux3e.siguiente=&aux2e;
                    t10.siguiente=&aux3e;
                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e10.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t10);
                    cout<<"entra "<<t10.lexema.toStdString();
                    mistack.push(e10);
                    cout<<"Transicion "<<e10.lexema.toStdString()<<endl;
                }
                if( thing3=="24" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  6 pops"<<endl;


                    t11.lexema=raux;
                    mistack.pop();
                    auxeg=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux2eg=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux3eg=mistack.top();
                    mistack.pop();
                    aux2eg.siguiente=&auxeg;
                    aux3eg.siguiente=&aux2eg;
                    t11.siguiente=&aux3eg;
                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e11.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t11);
                    cout<<"entra "<<t11.lexema.toStdString();
                    mistack.push(e11);
                    cout<<"Transicion "<<e11.lexema.toStdString()<<endl;
                }
                if( thing3=="28" )
                    {
                        cout<<"regla"<<thing3.toStdString()<<"  6 pops"<<endl;


                        t12.lexema=raux;
                        mistack.pop();
                        auxeh=mistack.top();
                        mistack.pop();
                        mistack.pop();
                        aux2eh=mistack.top();
                        mistack.pop();
                        mistack.pop();
                        aux3eh=mistack.top();
                        mistack.pop();
                        aux2eh.siguiente=&auxeh;
                        aux3eh.siguiente=&aux2eh;
                        t12.siguiente=&aux3eh;
                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e12.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t12);
                        cout<<"entra "<<t12.lexema.toStdString();
                        mistack.push(e12);
                        cout<<"Transicion "<<e12.lexema.toStdString()<<endl;
                }
                if( thing3=="34" )
                    {
                        cout<<"regla"<<thing3.toStdString()<<"  6 pops"<<endl;


                        t13.lexema=raux;
                        mistack.pop();
                        auxej=mistack.top();
                        mistack.pop();
                        mistack.pop();
                        aux2ej=mistack.top();
                        mistack.pop();
                        mistack.pop();
                        aux3ej=mistack.top();
                        mistack.pop();
                        aux2ej.siguiente=&auxej;
                        aux3ej.siguiente=&aux2ej;
                        t13.siguiente=&aux3ej;
                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e13.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t13);
                        cout<<"entra "<<t13.lexema.toStdString();
                        mistack.push(e13);
                        cout<<"Transicion "<<e13.lexema.toStdString()<<endl;
                }
                if( thing3=="43")
                {
                    cout<<"regla"<<thing3.toStdString()<<"  6 pops"<<endl;


                    t14.lexema=raux;
                    mistack.pop();
                    auxek=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux2ek=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux3ek=mistack.top();
                    mistack.pop();
                    aux2ek.siguiente=&auxek;
                    aux3ek.siguiente=&aux2ek;
                    t14.siguiente=&aux3ek;
                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e14.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t14);
                    cout<<"entra "<<t14.lexema.toStdString();
                    mistack.push(e14);
                    cout<<"Transicion "<<e14.lexema.toStdString()<<endl;
                }
                if( thing3=="46")
                {
                    cout<<"regla"<<thing3.toStdString()<<"  6 pops"<<endl;


                    t15.lexema=raux;
                    mistack.pop();
                    auxel=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux2el=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux3el=mistack.top();
                    mistack.pop();
                    aux2el.siguiente=&auxel;
                    aux3el.siguiente=&aux2el;
                    t15.siguiente=&aux3el;
                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e15.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t15);
                    cout<<"entra "<<t15.lexema.toStdString();
                    mistack.push(e15);
                    cout<<"Transicion "<<e15.lexema.toStdString()<<endl;
                }
                if( thing3=="47" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  6 pops"<<endl;


                    t16.lexema=raux;
                    mistack.pop();
                    auxez=mistack.top();   // expresion
                    mistack.pop();
                    mistack.pop();
                    aux2ez=mistack.top();  // OpSuma
                    mistack.pop();
                    mistack.pop();
                    aux3ez=mistack.top();  //Expresion
                    change5=*aux3ez.siguiente;
                    mistack.pop();
                    auxez.siguiente=&change5;
                    aux2ez.siguiente=&auxez;
                    aux3ez.siguiente=&aux2ez;
                    t16.siguiente=&aux3ez;
                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e16.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t16);
                    cout<<"entra "<<t16.lexema.toStdString();
                    mistack.push(e16);
                    cout<<"Transicion "<<e16.lexema.toStdString()<<endl;
                }
                if( thing3=="48" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  6 pops"<<endl;


                    t17.lexema=raux;
                    mistack.pop();
                    auxex=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux2ex=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux3ex=mistack.top();
                    mistack.pop();
                    aux2ex.siguiente=&auxex;
                    aux3ex.siguiente=&aux2ex;
                    t17.siguiente=&aux3ex;
                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e17.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t17);
                    cout<<"entra "<<t17.lexema.toStdString();
                    mistack.push(e17);
                    cout<<"Transicion "<<e17.lexema.toStdString()<<endl;
                }
                if( thing3=="49" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  6 pops"<<endl;


                    t18.lexema=raux;
                    mistack.pop();
                    auxec=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux2ec=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux3ec=mistack.top();
                    mistack.pop();
                    aux2ec.siguiente=&auxec;
                    aux3ec.siguiente=&aux2ec;
                    t18.siguiente=&aux3ec;
                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e18.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t18);
                    cout<<"entra "<<t18.lexema.toStdString();
                    mistack.push(e18);
                    cout<<"Transicion "<<e18.lexema.toStdString()<<endl;
                }
                if( thing3=="50" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  6 pops"<<endl;


                    t19.lexema=raux;
                    mistack.pop();
                    auxev=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux2ev=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux3ev=mistack.top();
                    mistack.pop();
                    aux2ev.siguiente=&auxev;
                    aux3ev.siguiente=&aux2ev;
                    t19.siguiente=&aux3ev;
                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e19.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t19);
                    cout<<"entra "<<t19.lexema.toStdString();
                    mistack.push(e19);
                    cout<<"Transicion "<<e19.lexema.toStdString()<<endl;
                }
                if( thing3=="51" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  6 pops"<<endl;


                    t20.lexema=raux;
                    mistack.pop();
                    auxeb=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux2eb=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux3eb=mistack.top();
                    mistack.pop();
                    aux2eb.siguiente=&auxeb;
                    aux3eb.siguiente=&aux2eb;
                    t20.siguiente=&aux3eb;
                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e20.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t20);
                    cout<<"entra "<<t20.lexema.toStdString();
                    mistack.push(e20);
                    cout<<"Transicion "<<e20.lexema.toStdString()<<endl;
                }
                if( thing3=='8' )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  6 pops"<<endl;


                    t21.lexema=raux;
                    mistack.pop();
                    auxen=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux2en=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux3en=mistack.top();
                    mistack.pop();
                    aux2en.siguiente=&auxen;
                    aux3en.siguiente=&aux2en;
                    t21.siguiente=&aux3en;
                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e21.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t21);
                    cout<<"entra "<<t21.lexema.toStdString();
                    mistack.push(e21);
                    cout<<"Transicion "<<e21.lexema.toStdString()<<endl;
                }
                if(thing3=="11")
                {
                    cout<<"regla"<<thing3.toStdString()<<"  6 pops"<<endl;


                    t22.lexema=raux;
                    mistack.pop();
                    auxem=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux2em=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux3em=mistack.top();
                    mistack.pop();
                    aux2em.siguiente=&auxem;
                    aux3em.siguiente=&aux2em;
                    t22.siguiente=&aux3em;
                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e22.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t22);
                    cout<<"entra "<<t22.lexema.toStdString();
                    mistack.push(e22);
                    cout<<"Transicion "<<e22.lexema.toStdString()<<endl;
                }






                if(thing3=='1')
                {
                    cout<<"regla"<<thing3.toStdString()<<"  2 pops"<<endl;


                    t23.lexema=raux;
                    mistack.pop();
                    auxr=mistack.top();
                    mistack.pop();
                    t23.siguiente=&auxr;

                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e23.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t23);
                    cout<<"entra "<<t23.lexema.toStdString();
                    mistack.push(e23);
                    cout<<"Transicion "<<e23.lexema.toStdString()<<endl;
                }
                if( thing3=="18" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  2 pops"<<endl;


                    if(ty==0)
                    {
                        t24.lexema=raux;
                        mistack.pop();
                        auxrq=mistack.top();
                        mistack.pop();
                        t24.siguiente=&auxrq;

                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e24.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t24);
                        cout<<"entra "<<t24.lexema.toStdString();
                        mistack.push(e24);
                        cout<<"Transicion "<<e24.lexema.toStdString()<<endl;
                    }
                    if(ty==1)
                    {
                        t25.lexema=raux;
                        mistack.pop();
                        tyler=mistack.top();
                        mistack.pop();
                        t25.siguiente=&tyler;

                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e25.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t25);
                        cout<<"entra "<<t25.lexema.toStdString();
                        mistack.push(e25);
                        cout<<"Transicion "<<e25.lexema.toStdString()<<endl;
                    }
                    if(ty==2)
                    {
                        t26.lexema=raux;
                        mistack.pop();
                        tyler2=mistack.top();
                        mistack.pop();
                        t26.siguiente=&tyler2;

                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e26.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t26);
                        cout<<"entra "<<t26.lexema.toStdString();
                        mistack.push(e26);
                        cout<<"Transicion "<<e26.lexema.toStdString()<<endl;
                    }
                    ty++;


                }
                if( thing3=="30" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  2 pops"<<endl;


                    t27.lexema=raux;
                    mistack.pop();
                    auxrw=mistack.top();
                    mistack.pop();
                    t27.siguiente=&auxrw;

                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e27.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t27);
                    cout<<"entra "<<t27.lexema.toStdString();
                    mistack.push(e27);
                    cout<<"Transicion "<<e27.lexema.toStdString()<<endl;
                }
                if(thing3=="35" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  2 pops"<<endl;


                    t28.lexema=raux;
                    mistack.pop();
                    auxre=mistack.top();
                    mistack.pop();
                    t28.siguiente=&auxre;

                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e28.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t28);
                    cout<<"entra "<<t28.lexema.toStdString();
                    mistack.push(e28);
                    cout<<"Transicion "<<e28.lexema.toStdString()<<endl;
                }
                if( thing3=="36" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  2 pops"<<endl;


                    if(sm==0)
                    {
                        t29.lexema=raux;
                        mistack.pop();
                        auxrr=mistack.top();
                        mistack.pop();
                        t29.siguiente=&auxrr;

                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e29.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t29);
                        cout<<"entra "<<t29.lexema.toStdString();
                        mistack.push(e29);
                        cout<<"Transicion "<<e29.lexema.toStdString()<<endl;
                    }
                    if(sm==1)
                    {
                        t30.lexema=raux;
                        mistack.pop();
                        Smith=mistack.top();
                        mistack.pop();
                        t30.siguiente=&Smith;

                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e30.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t30);
                        cout<<"entra "<<t30.lexema.toStdString();
                        mistack.push(e30);
                        cout<<"Transicion "<<e30.lexema.toStdString()<<endl;
                    }
                    sm++;


                }
                if(thing3=="37" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  2 pops"<<endl;


                    if(sec2==0)
                    {
                        t31.lexema=raux;
                        mistack.pop();
                        auxrt=mistack.top();
                        mistack.pop();
                        t31.siguiente=&auxrt;

                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e31.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t31);
                        cout<<"entra "<<t31.lexema.toStdString();
                        mistack.push(e31);
                        cout<<"Transicion "<<e31.lexema.toStdString()<<endl;
                    }

                    if(sec2==1)
                    {
                        t32.lexema=raux;
                        mistack.pop();
                        second2=mistack.top();
                        mistack.pop();
                        t32.siguiente=&second2;

                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e32.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t32);
                        cout<<"entra "<<t32.lexema.toStdString();
                        mistack.push(e32);
                        cout<<"Transicion "<<e32.lexema.toStdString()<<endl;
                    }

                    sec2++;


                }
                if(thing3=="38" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  2 pops"<<endl;


                    t33.lexema=raux;
                    mistack.pop();
                    auxry=mistack.top();
                    mistack.pop();
                    t33.siguiente=&auxry;

                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e33.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t33);
                    cout<<"entra "<<t33.lexema.toStdString();
                    mistack.push(e33);
                    cout<<"Transicion "<<e33.lexema.toStdString()<<endl;
                }
                if(thing3=="39" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  2 pops"<<endl;


                    t34.lexema=raux;
                    mistack.pop();
                    auxru=mistack.top();
                    mistack.pop();
                    t34.siguiente=&auxru;

                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e34.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t34);
                    cout<<"entra "<<t34.lexema.toStdString();
                    mistack.push(e34);
                    cout<<"Transicion "<<e34.lexema.toStdString()<<endl;
                }
                if(thing3=="41" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  2 pops"<<endl;


                    t35.lexema=raux;
                    mistack.pop();
                    auxri=mistack.top();
                    mistack.pop();
                    t35.siguiente=&auxri;

                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e35.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t35);
                    cout<<"entra "<<t35.lexema.toStdString();
                    mistack.push(e35);
                    cout<<"Transicion "<<e35.lexema.toStdString()<<endl;
                }
                if(thing3=="42" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  2 pops"<<endl;


                    t36.lexema=raux;
                    mistack.pop();
                    auxro=mistack.top();
                    mistack.pop();
                    t36.siguiente=&auxro;

                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e36.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t36);
                    cout<<"entra "<<t36.lexema.toStdString();
                    mistack.push(e36);
                    cout<<"Transicion "<<e36.lexema.toStdString()<<endl;
                }
                if( thing3=="52" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  2 pops"<<endl;


                    if(ka==0)
                    {
                        t37.lexema=raux;
                        mistack.pop();
                        auxrp=mistack.top();
                        mistack.pop();
                        t37.siguiente=&auxrp;

                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e37.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t37);
                        cout<<"entra "<<t37.lexema.toStdString();
                        mistack.push(e37);
                        cout<<"Transicion "<<e37.lexema.toStdString()<<endl;
                    }
                    if(ka==1)
                    {
                        t38.lexema=raux;
                        mistack.pop();
                        kali=mistack.top();
                        mistack.pop();
                        t38.siguiente=&kali;

                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e38.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t38);
                        cout<<"entra "<<t38.lexema.toStdString();
                        mistack.push(e38);
                        cout<<"Transicion "<<e38.lexema.toStdString()<<endl;
                    }
                    if(ka==2)
                    {
                        t39.lexema=raux;
                        mistack.pop();
                        Kali2=mistack.top();
                        mistack.pop();
                        t39.siguiente=&Kali2;

                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e39.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t39);
                        cout<<"entra "<<t39.lexema.toStdString();
                        mistack.push(e39);
                        cout<<"Transicion "<<e39.lexema.toStdString()<<endl;
                    }
                    if(ka==3)
                    {
                        t40.lexema=raux;
                        mistack.pop();
                        Kali3=mistack.top();
                        mistack.pop();
                        t40.siguiente=&Kali3;

                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e40.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t40);
                        cout<<"entra "<<t40.lexema.toStdString();
                        mistack.push(e40);
                        cout<<"Transicion "<<e40.lexema.toStdString()<<endl;
                    }

                    ka++;


                }
                if( thing3=='4' )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  2 pops"<<endl;


                    t41.lexema=raux;
                    mistack.pop();
                    auxra=mistack.top();
                    mistack.pop();
                    t41.siguiente=&auxra;

                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e41.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t41);
                    cout<<"entra "<<t41.lexema.toStdString();
                    mistack.push(e41);
                    cout<<"Transicion "<<e41.lexema.toStdString()<<endl;
                }
                if( thing3=='5' )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  2 pops"<<endl;


                    t42.lexema=raux;
                    mistack.pop();
                    auxrs=mistack.top();
                    mistack.pop();
                    t42.siguiente=&auxrs;

                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e42.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t42);
                    cout<<"entra "<<t42.lexema.toStdString();
                    mistack.push(e42);
                    cout<<"Transicion "<<e42.lexema.toStdString()<<endl;
                }
                if( thing3=="17")
                {
                    cout<<"regla"<<thing3.toStdString()<<"  2 pops"<<endl;




                    if(sec==0)
                    {
                        t43.lexema=raux;
                        mistack.pop();
                        auxrd=mistack.top();
                        mistack.pop();
                        t43.siguiente=&auxrd;

                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e43.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t43);
                        cout<<"entra "<<t43.lexema.toStdString();
                        mistack.push(e43);
                        cout<<"Transicion "<<e43.lexema.toStdString()<<endl;

                    }
                    if(sec==1)
                    {
                        t44.lexema=raux;
                        mistack.pop();
                        second=mistack.top();
                        mistack.pop();
                        t44.siguiente=&second;

                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e44.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t44);
                        cout<<"entra "<<t44.lexema.toStdString();
                        mistack.push(e44);
                        cout<<"Transicion "<<e44.lexema.toStdString()<<endl;
                    }
                    if(sec==2)
                    {
                        t70.lexema=raux;
                        mistack.pop();
                        second4=mistack.top();
                        mistack.pop();
                        t70.siguiente=&second4;

                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e70.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t70);
                        cout<<"entra "<<t70.lexema.toStdString();
                        mistack.push(e70);
                        cout<<"Transicion "<<e70.lexema.toStdString()<<endl;
                    }

                    sec++;


                }






                if(thing3=="19" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  0 pops"<<endl;

                    t45.lexema=raux;

                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e45.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t45);
                    cout<<"entra "<<t45.lexema.toStdString();
                    mistack.push(e45);
                    cout<<"Transicion "<<e45.lexema.toStdString()<<endl;
                }
                if(thing3=="26")
                {
                    cout<<"regla"<<thing3.toStdString()<<"  0 pops"<<endl;

                    t46.lexema=raux;

                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e46.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t46);
                    cout<<"entra "<<t46.lexema.toStdString();
                    mistack.push(e46);
                    cout<<"Transicion "<<e46.lexema.toStdString()<<endl;
                }

                if( thing3=="29" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  0 pops"<<endl;

                    t47.lexema=raux;

                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e47.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t47);
                    cout<<"entra "<<t47.lexema.toStdString();
                    mistack.push(e47);
                    cout<<"Transicion "<<e47.lexema.toStdString()<<endl;
                }

                if(thing3=="31")
                {
                    cout<<"regla"<<thing3.toStdString()<<"  0 pops"<<endl;

                    t48.lexema=raux;

                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e48.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t48);
                    cout<<"entra "<<t48.lexema.toStdString();
                    mistack.push(e48);
                    cout<<"Transicion "<<e48.lexema.toStdString()<<endl;
                }

                if( thing3=="33" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  0 pops"<<endl;

                    t49.lexema=raux;

                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e49.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t49);
                    cout<<"entra "<<t49.lexema.toStdString();
                    mistack.push(e49);
                    cout<<"Transicion "<<e49.lexema.toStdString()<<endl;
                }
                if( thing3=='2' )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  0 pops"<<endl;

                    t50.lexema=raux;

                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e50.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t50);
                    cout<<"entra "<<t50.lexema.toStdString();
                    mistack.push(e50);
                    cout<<"Transicion "<<e50.lexema.toStdString()<<endl;
                }
                if( thing3=='7' )
                {

                    cout<<"regla"<<thing3.toStdString()<<"  0 pops"<<endl;

                    if(safety==0)
                    {
                        t51.lexema=raux;


                        for (int i=0;i<46;i++ )
                        {

                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h1=i;
                            }
                         }
                        e51.lexema=accion2=table[mistack.top().lexema.toInt()][h1];
                        mistack.push(t51);
                        mistack.push(e51);
                        cout<<"entra "<<t51.lexema.toStdString();

                        cout<<"Transicion "<<e51.lexema.toStdString()<<endl;
                    }
                    if(safety==1)
                    {
                        t68.lexema=raux;

                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;


                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e68.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t68);
                        cout<<"entra "<<t68.lexema.toStdString();
                        mistack.push(e68);
                        cout<<"Transicion "<<e68.lexema.toStdString()<<endl;
                    }
                    if(safety==2)
                    {
                        t71.lexema=raux;

                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;


                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e71.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t71);
                        cout<<"entra "<<t71.lexema.toStdString();
                        mistack.push(e71);
                        cout<<"Transicion "<<e71.lexema.toStdString()<<endl;
                    }

                    safety++;


                }
                if( thing3=="10" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  0 pops"<<endl;

                    t52.lexema=raux;

                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e52.lexema=(accion=table[mistack.top().lexema.toInt()][h]);
                    mistack.push(t52);
                    cout<<"entra "<<t52.lexema.toStdString();
                    mistack.push(e52);
                    cout<<"Transicion "<<e52.lexema.toStdString()<<endl;
                }

                if( thing3=="12")
                {
                    cout<<"regla"<<thing3.toStdString()<<"  0 pops"<<endl;

                    t53.lexema=raux;

                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e53.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t53);
                    cout<<"entra "<<t53.lexema.toStdString();
                    mistack.push(e53);
                    cout<<"Transicion "<<e53.lexema.toStdString()<<endl;
                }
                if( thing3=="15")
                {
                    cout<<"regla"<<thing3.toStdString()<<"  0 pops"<<endl;

                    t54.lexema=raux;

                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e54.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t54);
                    cout<<"entra "<<t54.lexema.toStdString();
                    mistack.push(e54);
                    cout<<"Transicion "<<e54.lexema.toStdString()<<endl;
                }
                if(thing3=="20" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  4 pops"<<endl;


                    t55.lexema=raux;
                    mistack.pop();
                    auxt=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux2t=mistack.top();
                    mistack.pop();
                    aux2t.siguiente=&auxt;
                    t55.siguiente=&aux2t;
                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e55.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t55);
                    cout<<"entra "<<t55.lexema.toStdString();
                    mistack.push(e55);
                    cout<<"Transicion "<<e55.lexema.toStdString()<<endl;

                }
                if( thing3=="25" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  4 pops"<<endl;


                    t56.lexema=raux;
                    mistack.pop();
                    auxtq=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux2tq=mistack.top();
                    mistack.pop();
                    aux2tq.siguiente=&auxtq;
                    t56.siguiente=&aux2tq;
                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e56.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t56);
                    cout<<"entra "<<t56.lexema.toStdString();
                    mistack.push(e56);
                    cout<<"Transicion "<<e56.lexema.toStdString()<<endl;

                }
                if(thing3=="27" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  4 pops"<<endl;


                    t57.lexema=raux;
                    mistack.pop();
                    auxtw=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux2tw=mistack.top();
                    mistack.pop();
                    aux2tw.siguiente=&auxtw;
                    t57.siguiente=&aux2tw;
                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e57.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t57);
                    cout<<"entra "<<t57.lexema.toStdString();
                    mistack.push(e57);
                    cout<<"Transicion "<<e57.lexema.toStdString()<<endl;

                }
                if( thing3=="32" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  4 pops"<<endl;


                    t58.lexema=raux;
                    mistack.pop();
                    auxte=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux2te=mistack.top();
                    mistack.pop();
                    aux2te.siguiente=&auxte;
                    t58.siguiente=&aux2te;
                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e58.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t58);
                    cout<<"entra "<<t58.lexema.toStdString();
                    mistack.push(e58);
                    cout<<"Transicion "<<e58.lexema.toStdString()<<endl;

                }
                if(thing3=="44" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  4 pops"<<endl;


                    t59.lexema=raux;
                    mistack.pop();
                    auxtr=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux2tr=mistack.top();
                    mistack.pop();
                    aux2tr.siguiente=&auxtr;
                    t59.siguiente=&aux2tr;
                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e59.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t59);
                    cout<<"entra "<<t59.lexema.toStdString();
                    mistack.push(e59);
                    cout<<"Transicion "<<e59.lexema.toStdString()<<endl;

                }
                if(thing3=="45" )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  4 pops"<<endl;


                    t60.lexema=raux;
                    mistack.pop();
                    auxtt=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux2tt=mistack.top();
                    mistack.pop();
                    aux2tt.siguiente=&auxtt;
                    t60.siguiente=&aux2tt;
                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e60.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t60);
                    cout<<"entra "<<t60.lexema.toStdString();
                    mistack.push(e60);
                    cout<<"Transicion "<<e60.lexema.toStdString()<<endl;

                }
                if(thing3=='3' )
                {
                    cout<<"regla"<<thing3.toStdString()<<"  4 pops"<<endl;


                    t61.lexema=raux;
                    mistack.pop();
                    auxty=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux2ty=mistack.top();
                    change3=*aux2ty.siguiente;
                    mistack.pop();
                    aux2ty.siguiente=&change3;
                    auxty.siguiente=&aux2ty;
                    t61.siguiente=&auxty;
                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e61.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t61);
                    cout<<"entra "<<t61.lexema.toStdString();
                    mistack.push(e61);
                    cout<<"Transicion "<<e61.lexema.toStdString()<<endl;

                }
                if(thing3=="16")
                {
                    cout<<"regla"<<thing3.toStdString()<<"  4 pops"<<endl;
                    int flagx=0;



                    if(fra==0)
                    {
                        t62.lexema=raux;
                        mistack.pop();
                        auxtu=mistack.top(); //defLocales
                        mistack.pop();
                        mistack.pop();
                        aux2tu=mistack.top();  //defLocal
                        change=*aux2tu.siguiente;
                        mistack.pop();

                        auxtu.siguiente=&change;
                        aux2tu.siguiente=&auxtu;
                        t62.siguiente=&aux2tu;
                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e62.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t62);
                        cout<<"entra "<<t62.lexema.toStdString();
                        mistack.push(e62);
                        cout<<"Transicion "<<e62.lexema.toStdString()<<endl;
                    }
                    flagx=0;
                    if(fra==1)
                    {
                        t63.lexema=raux;
                        mistack.pop();
                        frank=mistack.top(); //defLocales
                        trial=auxtu.siguiente;
                        while(trial->siguiente!=nullptr)
                        {
                            cout<<"entro 1"<<endl;
                            flagx=1;
                            trial=trial->siguiente;
                        }
                        mistack.pop();
                        mistack.pop();
                        frank2=mistack.top();  //defLocal
                        frank4=*frank2.siguiente;
                        mistack.pop();
                        if(flagx==1)
                        {
                           trial->siguiente=&frank4;
                        }

                        frank2.siguiente=&frank;
                        t63.siguiente=&frank2;
                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e63.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t63);
                        cout<<"entra "<<t63.lexema.toStdString();
                        mistack.push(e63);
                        cout<<"Transicion "<<e63.lexema.toStdString()<<endl;
                    }
                    flagx=0;
                    if(fra==2)
                    {
                        t64.lexema=raux;
                        mistack.pop();
                        frank5=mistack.top(); //defLocales
                        trial2=frank5.siguiente;
                        while(trial2->siguiente!=NULL)
                        {
                            cout<<"entro 2"<<endl;
                            flagx=1;
                            trial2=trial2->siguiente;
                        }
                        mistack.pop();
                        mistack.pop();
                        frank7=mistack.top();  //defLocal
                        frank8=*frank7.siguiente;
                        mistack.pop();
                        if(flagx==1)
                        {
                           trial2->siguiente=&frank8;
                        }

                        frank7.siguiente=&frank5;
                        t64.siguiente=&frank7;
                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e64.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t64);
                        cout<<"entra "<<t64.lexema.toStdString();
                        mistack.push(e64);
                        cout<<"Transicion "<<e64.lexema.toStdString()<<endl;
                    }
                    flagx=0;
                    if(fra==3)
                    {
                        t65.lexema=raux;
                        mistack.pop();
                        frank9=mistack.top(); //defLocales
                        trial3=frank9.siguiente;
                        while(trial3->siguiente!=NULL)
                        {
                            cout<<"entro 3"<<endl;
                            flagx=1;
                            trial3=trial3->siguiente;
                        }
                        mistack.pop();
                        mistack.pop();
                        frank11=mistack.top();  //defLocal
                        frank12=*frank11.siguiente;
                        mistack.pop();
                        if(flagx==1)
                        {
                           trial3->siguiente=&frank12;
                        }

                        frank11.siguiente=&frank9;
                        t65.siguiente=&frank11;
                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e65.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t65);
                        cout<<"entra "<<t65.lexema.toStdString();
                        mistack.push(e65);
                        cout<<"Transicion "<<e65.lexema.toStdString()<<endl;
                    }
                    if(fra==4)
                    {
                        t66.lexema=raux;
                        mistack.pop();
                        frank13=mistack.top(); //defLocales
                        trial4=frank13.siguiente;
                        while(trial4->siguiente!=NULL)
                        {
                            cout<<"entro 4"<<endl;
                            flagx=1;
                            trial4=trial4->siguiente;
                        }
                        mistack.pop();
                        mistack.pop();
                        frank15=mistack.top();  //defLocal
                        frank16=*frank15.siguiente;
                        mistack.pop();
                        if(flagx==1)
                        {
                           trial4->siguiente=&frank16;
                        }

                        frank15.siguiente=&frank13;
                        t66.siguiente=&frank15;
                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e66.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t66);
                        cout<<"entra "<<t66.lexema.toStdString();
                        mistack.push(e66);
                        cout<<"Transicion "<<e66.lexema.toStdString()<<endl;
                    }
                    if(fra==5)
                    {
                        t72.lexema=raux;
                        mistack.pop();
                        frank17=mistack.top(); //defLocales
                        trial5=frank17.siguiente;
                        while(trial5->siguiente!=NULL)
                        {
                            cout<<"entro 5"<<endl;
                            flagx=1;
                            trial5=trial5->siguiente;
                        }
                        mistack.pop();
                        mistack.pop();
                        frank18=mistack.top();  //defLocal
                        frank19=*frank18.siguiente;
                        mistack.pop();
                        if(flagx==1)
                        {
                           trial5->siguiente=&frank19;
                        }

                        frank18.siguiente=&frank17;
                        t72.siguiente=&frank15;
                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e72.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t72);
                        cout<<"entra "<<t72.lexema.toStdString();
                        mistack.push(e72);
                        cout<<"Transicion "<<e72.lexema.toStdString()<<endl;
                    }
                    if(fra==6)
                    {
                        t73.lexema=raux;
                        mistack.pop();
                        frank20=mistack.top(); //defLocales
                        trial6=frank20.siguiente;
                        while(trial6->siguiente!=NULL)
                        {
                            cout<<"entro 6"<<endl;
                            flagx=1;
                            trial6=trial6->siguiente;
                        }
                        mistack.pop();
                        mistack.pop();
                        frank21=mistack.top();  //defLocal
                        frank22=*frank21.siguiente;
                        mistack.pop();
                        if(flagx==1)
                        {
                           trial6->siguiente=&frank22;
                        }

                        frank21.siguiente=&frank20;
                        t73.siguiente=&frank15;
                        int h;
                        for (int i=0;i<46;i++ )
                        {
                            QString aux17;

                            aux17=table2[i];
                            if(aux17==raux)
                            {
                                h=i;
                            }
                         }
                        e73.lexema=accion=table[mistack.top().lexema.toInt()][h];
                        mistack.push(t73);
                        cout<<"entra "<<t73.lexema.toStdString();
                        mistack.push(e73);
                        cout<<"Transicion "<<e73.lexema.toStdString()<<endl;
                    }


                    fra++;






                }
                if(thing3=="23")
                {
                    cout<<"regla"<<"23  10 pops"<<endl;


                    t67.lexema=raux;
                    mistack.pop();
                    auxy=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux2y=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux3y=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux4y=mistack.top();
                    mistack.pop();
                    mistack.pop();
                    aux5y=mistack.top();
                    mistack.pop();
                    aux2y.siguiente=&auxy;
                    aux3y.siguiente=&aux2y;
                    aux4y.siguiente=&aux3y;
                    aux5y.siguiente=&aux4y;
                    t67.siguiente=&aux5y;
                    int h;
                    for (int i=0;i<46;i++ )
                    {
                        QString aux17;

                        aux17=table2[i];
                        if(aux17==raux)
                        {
                            h=i;
                        }
                     }
                    e67.lexema=accion=table[mistack.top().lexema.toInt()][h];
                    mistack.push(t67);
                    cout<<"entra "<<t67.lexema.toStdString();
                    mistack.push(e67);
                    cout<<"Transicion "<<e67.lexema.toStdString()<<endl;

                }

                /*if(pop==0)
                {
                    cout<<"0 pops"<<endl;
                }else{
                    for (int i=0;i<pop*2 ;i++ ) {
                        mistack.pop();
                        cout<<"Pop"<<endl;
                    }
                }

                Nodo aux11=mistack.top();
                NoTerminal tem;
                tem.lexema=raux;
                mistack.push(tem);
                cout<<"Agregando"<<raux.toStdString()<<endl;
                Estado estado3;
                int h;
                for (int i=0;i<46;i++ )
                {
                    QString aux17;

                    aux17=table2[i];
                    if(aux17==raux)
                    {
                        h=i;
                    }
                 }
                cout<<aux11.lexema.toInt()<<"and   "<<h<<endl;
                estado3.lexema=accion=table[aux11.lexema.toInt()][h];
                mistack.push(estado3);
                cout<<" Transicion Agregando "<<accion.toStdString()<<endl;*/

            }

        }
        if(accion=="0")
        {
            QMessageBox msgBox;
            msgBox.setText("Error Sintactico");
            msgBox.exec();
            break;

        }


    }

    Nodo *iq2;
    iq2=&mistack.top();
    QString starting,starting2, variable1,variable2,variable3,type1,type2,type3,value1,value2,value3;
    int context=0,flag1=0,flag2=0;

    while(iq2->siguiente!=nullptr)
    {
        if(context==0)
        {
            if(iq2->lexema=="DefFunc")
            {
                context=1;
                iq2=iq2->siguiente;


            }
            if(iq2->lexema=="DefVar")
            {
                context=2;
                iq2=iq2->siguiente;

            }
            if(iq2->lexema=="Sentencia")
            {
                context=3;
                iq2=iq2->siguiente;

            }

        }
        if(context==1)
        {
            cout<<"entrando en defFunc"<<endl;
            starting=iq2->dato;
            iq2=iq2->siguiente;
            starting2=iq2->dato;
            context=0;

        }
        if(context==2)
        {
            cout<<"entrando en defVar"<<endl;
            if(flag1==0)
            {
                type3=iq2->dato;
                iq2=iq2->siguiente;
                variable3=iq2->dato;

            }
            if(flag1==1)
            {
                type2=iq2->dato;
                iq2=iq2->siguiente;
                variable2=iq2->dato;

            }
            if(flag1==2)
            {
                type1=iq2->dato;
                iq2=iq2->siguiente;
                variable1=iq2->dato;

            }

            flag1++;
            context=0;
        }
        if(context==3)
        {
            cout<<"entrando en sentencia"<<endl;
            if(flag2==0)
            {
                iq2=iq2->siguiente;
                iq2=iq2->siguiente;
                iq2=iq2->siguiente;
                iq2=iq2->siguiente;
                iq2=iq2->siguiente;
                value3=iq2->dato;
            }
            if(flag2==1)
            {
                iq2=iq2->siguiente;
                iq2=iq2->siguiente;
                iq2=iq2->siguiente;
                iq2=iq2->siguiente;
                iq2=iq2->siguiente;
                value1=iq2->dato;
            }
            if(flag2==2)
            {
                iq2=iq2->siguiente;
                iq2=iq2->siguiente;
                iq2=iq2->siguiente;
                iq2=iq2->siguiente;
                iq2=iq2->siguiente;
                value2=iq2->dato;
            }
            flag2++;
            context=0;
        }

        iq2=iq2->siguiente;

    }

    Container function;
    Container stuff1;
    Container stuff2;
    Container stuff3;


    function.type=starting;
    function.name=starting2;
    cout<<starting.toStdString()<<endl;
    cout<<starting2.toStdString()<<endl;
    cout<<endl;

    stuff1.type=type1;
    stuff1.name=variable1;
    stuff1.value=value1;
    cout<<type1.toStdString()<<endl;
    cout<<variable1.toStdString()<<endl;
    cout<<value1.toStdString()<<endl;
    cout<<endl;

    stuff2.type=type2;
    stuff2.name=variable2;
    stuff2.value=value2;
    cout<<type2.toStdString()<<endl;
    cout<<variable2.toStdString()<<endl;
    cout<<value2.toStdString()<<endl;
    cout<<endl;

    stuff3.type=type3;
    stuff3.name=variable3;
    stuff3.value=value3;
    cout<<type3.toStdString()<<endl;
    cout<<variable3.toStdString()<<endl;
    cout<<value3.toStdString()<<endl;
    cout<<endl;

    function.siguiente=&stuff1;
    stuff1.siguiente=&stuff2;
    stuff2.siguiente=&stuff3;

    if(type1==type2 and type1==type3)
    {
        QMessageBox msgBox2;
        msgBox2.setText("Semanticamente correcto");
        msgBox2.exec();

        if(value3=="+")
        {
            QString filename = "Suma.asm";
                QFile file(filename);
                if (file.open(QIODevice::ReadWrite)) {
                    QTextStream stream(&file);

                    stream << "org 100h \n"<<"mov ax, " << value1 <<"\n"<<"mov bx, "<< value2 <<"\n"<<"add bx,ax \n"<<"mov cx,bx \n"<<"ret";
                }

        }
        if(value3=="-")
        {
            QString filename = "Resta.asm";
                QFile file(filename);
                if (file.open(QIODevice::ReadWrite)) {
                    QTextStream stream(&file);


                    stream << "org 100h \n"<<"mov ax, " << value1 <<"\n"<<"mov bx, "<< value2 <<"\n"<<"sub ax,bx \n"<<"mov cx,ax \n"<<"ret";
                }

        }
    }else{
        QMessageBox msgBox2;
        msgBox2.setText("Error semantico");
        msgBox2.exec();
    }








}



